-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 30, 2018 at 11:34 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `learning`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE IF NOT EXISTS `admin_login` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`user_id`, `user_name`, `pass`) VALUES
(1, 'shriyansh', '12345'),
(2, 'hnyshri', '23456');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `m_id` int(10) NOT NULL AUTO_INCREMENT,
  `m_title` varchar(50) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`m_id`, `m_title`) VALUES
(1, 'Home'),
(2, 'C Language'),
(3, 'C++'),
(4, 'HTML'),
(7, 'shri');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `p_id` int(10) NOT NULL AUTO_INCREMENT,
  `p_title` varchar(100) NOT NULL,
  `p_desc` text NOT NULL,
  PRIMARY KEY (`p_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`p_id`, `p_title`, `p_desc`) VALUES
(1, 'C Language', 'this is shriyansh this is shriyansh this is shriyansh '),
(2, 'C++', 'this is shriyansh gupta this is shriyansh gupta this is shriyansh gupta this is shriyansh guptathis is shriyansh gupta '),
(7, 'hfdsa', 'fdewhf'),
(9, 'HTML', 'fahsiafshfsadfhaf');

-- --------------------------------------------------------

--
-- Table structure for table `sign_in`
--

CREATE TABLE IF NOT EXISTS `sign_in` (
  `sign_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` varchar(4) NOT NULL,
  `phone_no` varchar(10) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `pass` varchar(40) NOT NULL,
  PRIMARY KEY (`sign_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `sign_in`
--

INSERT INTO `sign_in` (`sign_id`, `user_name`, `name`, `gender`, `phone_no`, `email_id`, `pass`) VALUES
(1, '$fv', '$dd', '$Mal', '0', '$fdf', '0'),
(2, '$hgg', '$hfhf', '$Mal', '0', '$ff', '0'),
(3, '$', '$', '$', '0', '$', '$5555555'),
(4, '$', '$', '$', '$77777777', '$', '$'),
(5, '$', '$', '$', '$', '$', '$'),
(6, '$', '$', '$', '$', '$', '$'),
(7, '$', '$', '$', '$', '$', '$'),
(8, '$', '$', '$', '$', '$', '$'),
(9, '$Name is required', '$', '$', '$', '$', '$'),
(10, '$', '$', '$', '$', '$', '$'),
(11, '$', '$', '$', '$', '$', '$');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
